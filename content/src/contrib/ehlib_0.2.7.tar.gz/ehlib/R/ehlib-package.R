#' A package to create tetris chart visualizations in R
#'
#' @name ehlib-package
#' @docType package
#' @importFrom stats drop1 formula update rnorm runif kmeans model.frame
NULL
