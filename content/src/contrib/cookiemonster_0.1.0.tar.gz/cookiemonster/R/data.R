#' Raster values of cookie monster image.
#'
#' A three-dimensional array used to plot the cookie monster image.
"monster_raster"
