#' A package to create cookiemonster lineup plot using nullabor
#'
#' @name cookiemonster-package
#' @docType package
#' @importFrom ggplot2 ggplot aes xlim ylim annotation_raster theme_void
#' @importFrom ggplot2 facet_wrap
NULL
