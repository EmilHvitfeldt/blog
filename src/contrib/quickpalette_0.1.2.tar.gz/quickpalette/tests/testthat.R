library(testthat)
library(quickpalette)

test_check("quickpalette")
