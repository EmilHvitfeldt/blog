#' Quickly create palettes from outside sources
#'
#' @name quickpalette-package
#' @docType package
#' @importFrom grDevices rgb
#' @keywords internal
"_PACKAGE"
