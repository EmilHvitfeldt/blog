#' Bad words
#'
#' A list of words from Luis von Ahn's Research Group
#' \url{https://www.cs.cmu.edu/~biglou/resources/}. The list contains 1383
#' words/terms that could be found offensive. The list contains a lot of words
#' that most people don't find offensive, but it is a good start.
#'
#' @format A character vector with 1383 words.
"bad_words"
