#' A package that checks for offensive words in texts and ducuments
#'
#' @name offenseR-package
#' @docType package
NULL

globalVariables(c("n_words", "n_output"))
