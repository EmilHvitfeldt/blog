# offensiveR 0.1.3

# offensiveR 0.1.0

* Adding rstudio addin for selections.

# offensiveR 0.0.1

* Added a `NEWS.md` file to track changes to the package.
* Initial release on github.
